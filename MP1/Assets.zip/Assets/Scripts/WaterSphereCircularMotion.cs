//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/WaterSphereCircularMotion.cs - This is a component attached to a primitive sphere by AvatarState.cs
//@description: Defines the circular motion behavior of any sphere object with this script attached. Adapted code from Chat-GPT, full description can be found in
//              AlexBanningMP1/Assets/Scripts/FireCubeCircularMotion.cs

using UnityEngine;

public class WaterSphereCircularMotion : MonoBehaviour
{
    public Vector3 center = new Vector3(0f, 4f, 0f); // hard-coded center
    public float speed = 20f;   
    public Vector3 planeNormal = new Vector3(0f, 1f, -0.25f);

    private Vector3 u;
    private Vector3 v;
    private float angle;
    private float radius;

    void Start()
    {
        planeNormal.Normalize();
        Vector3 arbitrary = (Mathf.Abs(Vector3.Dot(planeNormal, Vector3.up)) > 0.99f)
            ? Vector3.right
            : Vector3.up;

        u = Vector3.Cross(planeNormal, arbitrary).normalized;
        v = Vector3.Cross(planeNormal, u).normalized;

        Vector3 offset = transform.position - center; // use Vector3 directly
        radius = offset.magnitude;

        float x = Vector3.Dot(offset, u);
        float y = Vector3.Dot(offset, v);
        angle = Mathf.Atan2(y, x);
    }

    void Update()
    {
        angle += speed * Time.deltaTime;
        Vector3 offset = (Mathf.Cos(angle) * u + Mathf.Sin(angle) * v) * radius;
        transform.position = center + offset;
    }
}