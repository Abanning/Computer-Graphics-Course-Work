//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/ColorController.cs - Main controller for CreationTarget color sliders
//@description: The controller for Color Sliders: RSlider, GSlider, and BSlider

using UnityEngine;
using UnityEngine.UI;

public class ColorController : MonoBehaviour
{
    [Header("Sliders")]
    public Slider RSlider;
    public Slider GSlider;
    public Slider BSlider;

    [Header("Target")]
    public Renderer targetRenderer;

    // Start is called before the first frame update
    void Start()
    {
        // Define event listeners in start
        RSlider.onValueChanged.AddListener(delegate { UpdateColor(); });
        GSlider.onValueChanged.AddListener(delegate { UpdateColor(); });
        BSlider.onValueChanged.AddListener(delegate { UpdateColor(); });

        UpdateColor();
    }

    // Update is called once per frame
    void UpdateColor()
    {
        // Update color every frame
        Color newColor = new Color(
            RSlider.value,
            GSlider.value,
            BSlider.value);

        if (targetRenderer != null)
        {
            targetRenderer.material.color = newColor;
        }
    }
}
