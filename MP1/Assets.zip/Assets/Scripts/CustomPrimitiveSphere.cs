//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/CustomPrimitiveSphere.cs - Component added to GameObject called by createSphere.cs
//@description: Defines the custom shape and behavior of a primitive sphere object as defined in MP1 - assignment spec

using System;
using UnityEngine;
using UnityEngine.UI;

public class CustomPrimitiveSphere : MonoBehaviour
{
    public ToggleGroup ToggleGroup;
    public float speed = 1f; // Set speed
    public float rotationSpeed = 45f; // Set angular speed

    // Define upper and lower bounds
    public float minY = 0.0f;
    public float maxY = 5.0f;

    private Vector3 direction = Vector3.up; // Define direction vector
    private Renderer rend;
    private readonly String objectTag = "DynamicObject"; // Tag for easy sorting later

    // Start is called before the first frame update
    void Start()
    {
        gameObject.tag = objectTag; // Set objectTag
        transform.localScale = new Vector3(0.5f, 1f, 1f); // Set scale

        // Check for out of bounds condition
        if (transform.position.y > maxY)
        {
            direction = Vector3.down;
        }

        // Get ToggleGroup
        GameObject groupObj = GameObject.FindGameObjectWithTag("PrimTog");
        if (groupObj != null)
        {
            ToggleGroup = groupObj.GetComponent<ToggleGroup>();
        }

        rend = GetComponent<Renderer>(); // Get renderer for color changes
        UpdateColor(); // Ensure color is updated before first frame
    }

    // Update is called once per frame
    void Update()
    {
        // Check for LMB click
        if (Input.GetMouseButtonDown(0))
        {
            DestructionHandler();
        }

        transform.position += speed * Time.smoothDeltaTime * direction; // Update position

        // Check for out of bounds, update color on direction change
        if (transform.position.y >= maxY)
        {
            direction = Vector3.down;
            UpdateColor();
        }
        else if (transform.position.y <= minY)
        {
            direction = Vector3.up;
            UpdateColor();
        }

        transform.Rotate(Vector3.up, rotationSpeed * Time.smoothDeltaTime); // Update rotation
    }

    // Function that updates the material color based on the direction vector
    void UpdateColor()
    {
        if (rend != null)
        {
            rend.material.color = (direction == Vector3.up) ? new Color(1f, 1f, 1f) : new Color(1f, 0f, 1f);
        }
    }

    // Checks every LMB click to see if mousePos is on the object, destroys obj if so
    void DestructionHandler()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.gameObject == gameObject)
            {
                ClearToggles(); // Clear UI ToggleGroup toggles
                Destroy(gameObject);
            }
        }
    }

    // Function that clears all toggles on the ToggleGroup UI element
    public void ClearToggles()
    {
        if (ToggleGroup != null)
        {
            ToggleGroup.SetAllTogglesOff();
        }
    }
}
