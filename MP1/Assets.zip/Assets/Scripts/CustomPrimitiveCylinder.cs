//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/CustomPrimitiveCylinder.cs - Component added to GameObject called by createCylinder.cs
//@description: Defines the custom shape and behavior of a primitive cylinder object as defined in MP1 - assignment spec

using System;
using UnityEngine;
using UnityEngine.UI;

public class CustomPrimitiveCylinder : MonoBehaviour
{
    public ToggleGroup ToggleGroup;
    public float speed = 1.5f; // Set speed
    public float rotationSpeed = 90f; // Set angular speed

    // Define upper and lower bounds
    public float minZ = 0.0f;
    public float maxZ = 5.0f;

    private Vector3 direction = Vector3.forward; // Define direction vector
    private Renderer rend;
    private bool reverseFlag = false; // Needed when object is placed out of bounds
    private readonly String objectTag = "DynamicObject"; // Tag name for easy sorting of dynamic objects

    // Start is called before the first frame update
    void Start()
    {
        gameObject.tag = objectTag; // Set object tag
        transform.localScale = new Vector3(0.5f, 1f, 1f); // Set scale

        // Check for out of bounds placement
        if (transform.position.z > maxZ)
        {
            direction = Vector3.back;
        }

        // Get ToggleGroup
        GameObject groupObj = GameObject.FindGameObjectWithTag("PrimTog");
        if (groupObj != null)
        {
            ToggleGroup = groupObj.GetComponent<ToggleGroup>();
        }

        rend = GetComponent<Renderer>();
        UpdateColor(); // Ensure color is set correctly based on direction vector
    }

    // Update is called once per frame
    void Update()
    {
        // Watch for mouse click
        if (Input.GetMouseButtonDown(0))
        {
            DestructionHandler();
        }

        transform.position += speed * Time.smoothDeltaTime * direction; // Update position

        // Check for out of bounds condition
        if (transform.position.z >= maxZ)
        {
            direction = Vector3.back;
            UpdateColor();
            reverseFlag = true;
        }
        else if (transform.position.z <= minZ && reverseFlag)
        {
            direction = Vector3.forward;
            UpdateColor();
        }

        transform.Rotate(Vector3.up, rotationSpeed * Time.smoothDeltaTime); // Update rotation
    }

    // Updates the material color based on the direction vector
    void UpdateColor()
    {
        if (rend != null)
        {
            rend.material.color = (direction == Vector3.forward) ? new Color(1f, 1f, 1f) : new Color(0f, 1f, 1f);
        }
    }

    // Handler activated at LMB click, determines if the object is in the path of the click and destroys the object if so
    void DestructionHandler()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.gameObject == gameObject)
            {
                ClearToggles(); // Clear all UI toggles on destroy
                Destroy(gameObject);
            }
        }
    }

    // Function that clears all ToggleGroup UI checks
    public void ClearToggles()
    {
        if (ToggleGroup != null)
        {
            ToggleGroup.SetAllTogglesOff();
        }
    }
}