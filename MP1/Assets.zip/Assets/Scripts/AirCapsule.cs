//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/AirCapsule.cs - This is a component attached to a primitive capsule by AvatarState.cs
//@description: Defines a primitive capsule's rotational behavior

using UnityEngine;

public class AirCapsule : MonoBehaviour
{
    private float rotationSpeed = 400f; // Set rotation speed in initialization
    private Vector3 rotationAxis = new Vector3(-1f, 1f, 0f); // Define rotational vector (doesn't really matter, just not y-axis because we won't be able to tell it's spinning)
    // Start is called before the first frame update
    void Start()
    {
        // Nothing needed in start function
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(rotationAxis, rotationSpeed * Time.smoothDeltaTime); // Update rotation
    }
}
