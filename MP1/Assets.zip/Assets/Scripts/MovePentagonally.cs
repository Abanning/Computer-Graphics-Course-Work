//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/MovePentagonally.cs - Component script added to Primitive EarthCylinder in AvatarState.cs
//@description: Moves the gameObject this script is added to in a pentagonal fashion around the origin (0, 4, 0). Used in AvatarState.cs animation

using UnityEngine;

public class MovePentagonally : MonoBehaviour
{
    private float speed = 20f; // Set speed

    // Define target positions in pentagon
    private Vector3[] targets = {
        new(-1f, 3f, -2f),
        new(-2.5f, 5f, 0f),
        new(0f, 6f, 2f),
        new(2.5f, 5f, 0f),
        new(1f, 3f, -2f)

    };
    private int targetIndex = 1; // First index is second spot in vector because we spawn at point 0

    // Start is called before the first frame update
    void Start()
    {
        speed = 20f; // Set speed again
    }

    // Update is called once per frame
    void Update()
    {
        float tStep = speed * Time.smoothDeltaTime; // Calculate tStep

        transform.position = Vector3.MoveTowards(transform.position, targets[targetIndex], tStep); // update position

        // Check if we have made it to the next target spot, if so, update targetIndex
        if (transform.position == targets[targetIndex])
        {
            targetIndex++;
            if (targetIndex >= targets.Length)
                targetIndex = 0;
        }
    }
}
