//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/EarthCylinder.cs - Component script for primitive cylinder, called by AvatarState.cs
//@description: A Component definition for the rotation of an "Earth" element rock, defined in the animation script AvatarState.cs

using UnityEngine;

public class EarthCylinder : MonoBehaviour
{
    private float rotationSpeed; 
    private Vector3 rotationAxis;

    // Start is called before the first frame update
    void Start()
    {
        rotationSpeed = 500f; // Set angular speed
        rotationAxis = new Vector3(-1f, 1f, 1f); // Set rotationAxis vector
    }

    // Update is called once per frame
    void Update()
    {
        float rStep = rotationSpeed * Time.smoothDeltaTime; // Calculate rotationStep
        
        transform.Rotate(rotationAxis, rStep); // Update rotation
    }
}
