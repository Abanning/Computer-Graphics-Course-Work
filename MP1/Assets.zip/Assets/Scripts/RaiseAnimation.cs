//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/RaiseAnimation.cs - Called by AvatarState.cs
//@description: An animation that raises the CreationTarget from the origin (0f, 0.2f, 0f) -> (0f, 4.2f, 0f)

using UnityEngine;

public class RaiseAnimation : MonoBehaviour
{
    private float speed = 1f; // Set speed
    private System.Action onComplete;
    private Vector3 targetVector = new Vector3(0f, 4.2f, 0f); // Set target vector
    private Color startColor;
    private Color targetColor = new Color(0f, 0.6f, 0.8f); // Set target color (blueish)
    private GameObject CreationTarget;
    private float duration = 2f; // Set animation duration
    private float elapsed = 0f; // Set elapsed time
    private Renderer rend;

    public void Init(System.Action callback)
    {
        onComplete = callback; // System callback for notifying master
    }

    // Start is called before the first frame update
    void Start()
    {
        CreationTarget = this.gameObject; // Set CreationTarget
        rend = CreationTarget.GetComponent<Renderer>(); // Assign renderer
    }

    // Update is called once per frame
    void Update()
    {
        // Calculate floats
        float step = speed * Time.smoothDeltaTime; // Get step
        float t = Mathf.Clamp01(elapsed / duration / 600f); // delta t for LERP function, uses elapsed/duration to calculate how quickly to change.

        // Set start color to current
        startColor = rend.material.color;

        // Upudate position and color with MoveTowards and LERP for smooth transition
        CreationTarget.transform.position = Vector3.MoveTowards(CreationTarget.transform.position, targetVector, step);
        rend.material.color = Color.Lerp(startColor, targetColor, t);
        elapsed += Time.deltaTime; // Update elapsed time

        // If it has reached the target, complete function
        if (CreationTarget.transform.position == targetVector)
        {
            rend.material.color = targetColor;
            CreationTarget.transform.position = targetVector;

            onComplete?.Invoke();
            Destroy(this);
        }
    }
}
