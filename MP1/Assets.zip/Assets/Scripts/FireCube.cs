//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/FireCube.cs - Component script added to primitive cube, called by AvatarState.cs
//@description: Defines the rotation of a "FireCube" element in the animation AvatarState.cs

using UnityEngine;

public class FireCube : MonoBehaviour
{
    private float rotationSpeed = 500f; // Set rotation speed
    private Vector3 rotationAxis = Vector3.up; // Set rotationAxis vector

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        float step = rotationSpeed * Time.deltaTime; // Calculate rotation step
        transform.Rotate(rotationAxis, step); // Update rotation
    }
}
