//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/MoveToOriginAnimation.cs - Called in AvatarState.cs twice
//@description: Moves the CreationTarget slowly and smoothly to the origin of the CreationPlane (0f, 0.2f, 0f) - sitting on the surface

using UnityEngine;

public class MoveToOriginAnimation : MonoBehaviour
{
    public System.Action onComplete;

    private GameObject CreationTarget;
    private Renderer rend;
    private Vector3 targetLocation = new Vector3(0f, 0.2f, 0f);
    private Color startColor;
    private Color targetColor = Color.black;
    private float speed = 2f;
    private float colorDuration = 2f;
    private float elapsed = 0f;

    void Start()
    {
        CreationTarget = this.gameObject; // Set creation target
        rend = CreationTarget.GetComponent<Renderer>(); // Setup renderer for smooth color change during animation
    }

    void Update()
    {
        // Move towards target
        CreationTarget.transform.position = Vector3.MoveTowards(CreationTarget.transform.position, targetLocation, speed * Time.deltaTime);

        // Lerp (linear interpolation) color over time
        elapsed += Time.deltaTime;
        float t = Mathf.Clamp01(elapsed / colorDuration / 600f);
        startColor = rend.material.color;
        rend.material.color = Color.Lerp(startColor, targetColor, t);

        // Check if both movement and color are finished
        if (CreationTarget.transform.position == targetLocation)
        {
            rend.material.color = targetColor;
            CreationTarget.transform.position = targetLocation;
            
            onComplete?.Invoke(); // Send message to calling master that this process is completed
            Destroy(this); // Destroy self
        }
    }
}