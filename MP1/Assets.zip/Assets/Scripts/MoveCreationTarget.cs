//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/MoveCreationTarget.cs - Component script added to CreationPlane, watching for mouse click event
//@description: Checks for a LMB click on the CreationPlane to move CreationTarget to the desired location

using UnityEngine;

public class MoveCreationTarget : MonoBehaviour
{
    public GameObject CreationTarget;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        // Check for LMB click
        if (Input.GetMouseButtonDown(0))
        {
            moveCreationTargetToMousePos();
        }
    }

    // Handler function to check for raycast hit with CreationPlane, if so, move CreationTarget to that point
    void moveCreationTargetToMousePos()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.gameObject == gameObject)
            {
                if (CreationTarget != null)
                {
                    Vector3 newPos = hit.point;
                    newPos.y = 0.2f;
                    CreationTarget.transform.position = newPos;
                }
            }
        }
    }
}
