//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/FreezeAllObjects.cs - Script called by FreezeToggle event listener
//@description: Freezes all primitive objects created in place and disables deletion, until unchecked

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FreezeAllObjects : MonoBehaviour
{
    public Toggle FreezeToggle;

    private readonly string objectTag = "DynamicObject"; // Tag for easy sorting

    // store movement scripts
    private List<MonoBehaviour> movementScripts = new List<MonoBehaviour>(); // List of scripts we want to freeze

    void Start()
    {
        FreezeToggle.onValueChanged.AddListener(OnToggleChanged); // Add event listener on FreezeToggle
    }

    void OnToggleChanged(bool isOn)
    {
        GameObject[] objects = GameObject.FindGameObjectsWithTag(objectTag); // Get all objects with the Dynamic Objects tag

        // Check each object for a CustomPrimitiveScript, if it has one, add the script to the list of MonoBeahviours we want to freeze
        foreach (GameObject obj in objects)
        {
            var sphere = obj.GetComponent<CustomPrimitiveSphere>();
            if (sphere != null)
            {
                movementScripts.Add(sphere);
            }

            var cylinder = obj.GetComponent<CustomPrimitiveCylinder>();
            if (cylinder != null)
            {
                movementScripts.Add(cylinder);
            }

            var cube = obj.GetComponent<CustomPrimitiveCube>();
            if (cube != null)
            {
                movementScripts.Add(cube);
            }
        }

        // For each list item, disable it
        foreach (MonoBehaviour script in movementScripts)
        {
            if (script != null)
                script.enabled = !isOn;  // disable movement while frozen
        }
    }
}