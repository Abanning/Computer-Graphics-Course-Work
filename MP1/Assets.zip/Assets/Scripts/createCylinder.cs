//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/createCylinder.cs - Called by 'Create Cylinder' toggle event
//@description: A script that creates a Cylinder primitive at the CreationTarget position whenever the 'Create Cylinder' toggle is selected
//              and adds a CustomPrimitiveCylinder component to this object aligned with the definition in the MP1 - assignment spec

using UnityEngine;

public class createCylinder : MonoBehaviour
{
    public GameObject CreationTarget;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    
    // Event listener connected to CylinderToggle
    public void OnToggleChanged(bool isOn)
    {
        if (isOn && CreationTarget != null)
        {
            GameObject newCylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            newCylinder.transform.position = CreationTarget.transform.position;
            newCylinder.transform.position += new Vector3(0f, 0.8f, 0f);
            newCylinder.AddComponent<CustomPrimitiveCylinder>();
        }
    }
}
