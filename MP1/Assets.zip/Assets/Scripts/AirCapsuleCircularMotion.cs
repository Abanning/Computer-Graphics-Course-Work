//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/AirCapsuleCircularMotion.cs - This is a component attached to a primitive capsule by AvatarState.cs
//@description: Defines the circular motion behavior of any capsule object with this script attached. Adapted code from Chat-GPT, full description can be found in
//              AlexBanningMP1/Assets/Scripts/FireCubeCircularMotion.cs

using UnityEngine;

// Class definition
public class AirCapsuleCircularMotion : MonoBehaviour
{
    public Vector3 center = new Vector3(0f, 4f, 0f); // hard-coded center
    public float speed = 20f; // Set speed
    public Vector3 planeNormal = new Vector3(-1f, 1f, 0f); // Set normal vector (orthogonal positive vector from desired plane) -> here, that is a vector pointing diagonally up left (quadrant 2)

    private Vector3 u; // Component vector
    private Vector3 v; // Component vector
    private float angle;
    private float radius; // Radius of circle motion

    void Start()
    {
        // Calculate vector components in start function
        planeNormal.Normalize();
        Vector3 arbitrary = (Mathf.Abs(Vector3.Dot(planeNormal, Vector3.up)) > 0.99f)
            ? Vector3.right
            : Vector3.up;

        u = Vector3.Cross(planeNormal, arbitrary).normalized;
        v = Vector3.Cross(planeNormal, u).normalized;

        Vector3 offset = transform.position - center; // use Vector3 directly
        radius = offset.magnitude;

        float x = Vector3.Dot(offset, u);
        float y = Vector3.Dot(offset, v);
        angle = Mathf.Atan2(y, x);
    }

    void Update()
    {
        angle += speed * Time.deltaTime; // Update angle 
        Vector3 offset = (Mathf.Cos(angle) * u + Mathf.Sin(angle) * v) * radius; // Circular movement math description
        transform.position = center + offset; // Transform based on center and calculated offset
    }
}