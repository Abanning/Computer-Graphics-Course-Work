//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/AvatarState.cs - An animation script for extra credit.
//@description: Animates an "Avatar State." The CreationTarget slowly shifts color back to black while moving to the origin, then
//              it is lifted up to the air and turns blue, spawns earth, fire, air, and water "elements" (gameObjects of primitive types with colors to
//              distinguish), they rotate around the CreationTarget, then are all sequentially shot towards the camera and destroyed upon impact.
//              The CreationTarget is then lowered back to the ground, where normal operations of the game can continue.

using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AvatarState : MonoBehaviour
{
    private readonly string objectTag = "DynamicObject"; // Tag definition to quickly find gameObjects
    private GameObject CreationTarget; // CreationTarget is the main object we care about in this animation, a global point of reference
    private bool inAvatarSequence = false; // A boolean used to disable repeat inputs during this animation

    // Start is called before the first frame update
    void Start()
    {
        CreationTarget = this.gameObject; // Define game object in start function (always going to be whichever object this script is attached to)
    }

    // Update is called once per frame
    void Update()
    {
        // Watch for space key input
        if (Input.GetKeyDown(KeyCode.Space) && !inAvatarSequence)
        {
            StartCoroutine(EnterAvatarStateSequence()); // Start IEnumerator routine (I use this data type so I can call yield return and wait for subroutines to finish, since animation is dependent on timing)
            inAvatarSequence = true; // Set flag to disable space input
        }
    }

    // Deifnes animation sequences for an AvatarState animation 
    private IEnumerator EnterAvatarStateSequence()
    {
        // Disable all interactions
        DisableToggles(); // Disable Toggles
        DisableSliders(); // Disable Sliders
        DisableCreationTargetMovement(); // Disable LMB Click to move CreationTarget

        // Delete all  Dynamic objects
        DeleteAllObjects();
        Debug.Log("Objects Deleted");

        // Reset CreationTarget
        if (CreationTarget.transform.position != new Vector3(0f, 0.2f, 0f))
        {
            MoveToOriginAnimation moveAnim = CreationTarget.AddComponent<MoveToOriginAnimation>();
            yield return new WaitWhile(() => moveAnim != null); // Wait for animation to finish to continue
        }
        Debug.Log("CreationTarget Reset");

        ResetSliders(); // Reset slider positions, we don't care about user input during the animation
        Debug.Log("Sliders Reset");

        // Raise CreationTarget
        RaiseAnimation raiseAnim = CreationTarget.AddComponent<RaiseAnimation>();
        yield return new WaitWhile(() => raiseAnim != null); // Wait for animation to finish to continue
        Debug.Log("CreationTarget raised");

        // Spawn Geometries (Each geometry gets a script assigned for movement definition)
        yield return StartCoroutine(SpawnGeometriesSequence()); // Wait for animation to finish to continue
        Debug.Log("Geometries Spawned");

        // Shoot Geometries Infinitely Outward, wait until offscreen, destroy objects
        yield return StartCoroutine(ShootGeometriesSequence()); // Wait for animation to finish to continue
        Debug.Log("Geometries Shot!");

        // Lower CreationTarget and reset state (no toggles checked, creation target is black, any RGB sliders reset)
        if (CreationTarget.transform.position != new Vector3(0f, 0.2f, 0f))
        {
            MoveToOriginAnimation moveAnim = CreationTarget.AddComponent<MoveToOriginAnimation>();
            yield return new WaitWhile(() => moveAnim != null); // Wait for animation to finish to continue
        }
        Debug.Log("CreationTarget Reset");

        // Re-enable functionality
        EnableToggles(); // Re-enable Toggles
        ClearToggles();
        EnableSliders(); // Re-enable Sliders
        EnableCreationTargetMovement(); // Re-enable LMB Click
        inAvatarSequence = false; // Disable flag to allow for space input
    }

    // Disables LMB Click functionality for CreationTarget placement
    void DisableCreationTargetMovement()
    {
        MoveCreationTarget script = GameObject.Find("CreationPlane").GetComponent<MoveCreationTarget>();
        script.enabled = false;
    }

    // Enables LMB Click functionality for CreationTarget placement
    void EnableCreationTargetMovement()
    {
        MoveCreationTarget script = GameObject.Find("CreationPlane").GetComponent<MoveCreationTarget>();
        script.enabled = true;
    }

    // Disables all the toggles during animation
    void DisableToggles()
    {
        Toggle SphereToggle = GameObject.Find("SphereToggle").GetComponent<Toggle>();
        SphereToggle.interactable = false;

        Toggle CubeToggle = GameObject.Find("CubeToggle").GetComponent<Toggle>();
        CubeToggle.interactable = false;

        Toggle CylinderToggle = GameObject.Find("CylinderToggle").GetComponent<Toggle>();
        CylinderToggle.interactable = false;

        Toggle FreezeToggle = GameObject.Find("FreezeToggle").GetComponent<Toggle>();
        FreezeToggle.interactable = false;
    }

    // Enables the toggle functionality
    void EnableToggles()
    {
        Toggle SphereToggle = GameObject.Find("SphereToggle").GetComponent<Toggle>();
        SphereToggle.interactable = true;

        Toggle CubeToggle = GameObject.Find("CubeToggle").GetComponent<Toggle>();
        CubeToggle.interactable = true;

        Toggle CylinderToggle = GameObject.Find("CylinderToggle").GetComponent<Toggle>();
        CylinderToggle.interactable = true;

        Toggle FreezeToggle = GameObject.Find("FreezeToggle").GetComponent<Toggle>();
        FreezeToggle.interactable = true;
    }

    void ClearToggles()
    {
        ToggleGroup tg = GameObject.FindGameObjectWithTag("PrimTog").GetComponent<ToggleGroup>();
        tg.SetAllTogglesOff();
    }

    // Disables the slider functionality
    void DisableSliders()
    {
        // Disable slider input while script runs
        Slider RSlider = GameObject.Find("RSlider").GetComponent<Slider>();
        RSlider.enabled = false;
        Slider GSlider = GameObject.Find("GSlider").GetComponent<Slider>();
        GSlider.enabled = false;
        Slider BSlider = GameObject.Find("BSlider").GetComponent<Slider>();
        BSlider.enabled = false;
    }

    // Enable the slider functionality
    void EnableSliders()
    {
        // Disable slider input while script runs
        Slider RSlider = GameObject.Find("RSlider").GetComponent<Slider>();
        RSlider.enabled = true;
        Slider GSlider = GameObject.Find("GSlider").GetComponent<Slider>();
        GSlider.enabled = true;
        Slider BSlider = GameObject.Find("BSlider").GetComponent<Slider>();
        BSlider.enabled = true;
    }

    // Deletes all Objects with a defined tag
    void DeleteAllObjects()
    {
        GameObject[] objs = GameObject.FindGameObjectsWithTag(objectTag); // objectTag = "DynamicObject" (any object created with the toggle menu)

        foreach (GameObject obj in objs)
        {
            Destroy(obj);
        }
    }

    // Resets the slider values to 0
    void ResetSliders()
    {
        Slider RSlider = GameObject.Find("RSlider").GetComponent<Slider>();
        RSlider.value = 0f;

        Slider GSlider = GameObject.Find("GSlider").GetComponent<Slider>();
        GSlider.value = 0f;

        Slider BSlider = GameObject.Find("BSlider").GetComponent<Slider>();
        BSlider.value = 0f;
    }

    // Spawns Geometries for the AvatarState animation
    private IEnumerator SpawnGeometriesSequence()
    {
        yield return StartCoroutine(SpawnEarth());
        yield return StartCoroutine(SpawnFire());
        yield return StartCoroutine(SpawnAir());
        yield return StartCoroutine(SpawnWater());
    }

    // SpawnEarth Cylinders that move in a pentagonal shape defined in AlexBanningMP1/Assets/Scripts/EarthCylinder.cs
    private IEnumerator SpawnEarth()
    {
        for (int i = 0; i < 16; i++)
        {
            GameObject newCylinder = GameObject.CreatePrimitive(PrimitiveType.Cylinder); // Create primitive
            // Assign random x, y, and z values to make slight variations in scale to make it look more like real rocks
            float x = Random.Range(0.05f, 0.25f);
            float y = Random.Range(0.05f, 0.25f);
            float z = Random.Range(0.05f, 0.25f);
            newCylinder.transform.localScale = new Vector3(x, y, z); // Define the transform.localScale by these values

            newCylinder.transform.position = CreationTarget.transform.position; // Set position initially at CreationTarget as origin
            newCylinder.transform.position -= new Vector3(1f, 1f, 2f); // Offset matches the first position in a targetPositions[] in AlexBanningMP1/Assets/Scripts/MovePentagonally.cs (to ensure spawn point and the last point in their movement match)

            // Get the renderer component to change color
            Renderer rend = newCylinder.GetComponent<Renderer>();
            rend.material.color = new Color(0.5f, 0.29f, 0.01f);

            newCylinder.tag = "Earth"; // Give cylinder an "Earth" tag to help with shooting it later
            newCylinder.AddComponent<EarthCylinder>(); // Add EarthCylinder component to define rotation
            newCylinder.AddComponent<MovePentagonally>(); // Add MovePentagonally component to define rotation in Pentagon shape around the CreationTarget
            // Wait for animation to begin
            yield return new WaitForSeconds(1f / 13f); // Delay to space objects out
        }
        yield return new WaitForSeconds(0.5f); // Wait for animation to settle before moving on
    }

    // Spawns FireCube objects that move in a circle about a defined plane for the AvatarState animation
    private IEnumerator SpawnFire()
    {
        // Create 20 cubes
        for (int i = 0; i < 20; i++)
        {
            GameObject newCube = GameObject.CreatePrimitive(PrimitiveType.Cube); // Create primitive shape
            newCube.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f); // Give all the same local scale since we want them to blend together a bit
            newCube.transform.position = CreationTarget.transform.position; // Set initial position as CreationTarget origin
            newCube.transform.position += new Vector3(-1f, 2f, 1f); // Offset by the radius we want the circle to start at

            // Get the renderer component to change color to "fire" color - lighter red
            Renderer rend = newCube.GetComponent<Renderer>();
            rend.material.color = new Color(1f, 0.02f, 0f);

            newCube.tag = "Fire"; // Assign "Fire" tag for easy shooting later
            newCube.AddComponent<FireCube>(); // Add FireCube component to rotation definition
            newCube.AddComponent<FireCubeCircularMotion>(); // Add FireCubeCircularMotion component to define rotation about a defined plane
            // Wait for animation to begin
            yield return new WaitForSeconds(1f / 17f); // Delay to space objects out
        }
        yield return new WaitForSeconds(0.5f); // Wait for animation to settle before moving on
    }

    // Spawns AirCapsule objects that move in a circle about a defined plane for the AvatarState animation
    private IEnumerator SpawnAir()
    {
        // Spawn 20 capsules
        for (int i = 0; i < 20; i++)
        {
            GameObject newCapsule = GameObject.CreatePrimitive(PrimitiveType.Capsule); // Create primitive shape
            newCapsule.transform.localScale = new Vector3(0.2f, 0.1f, 0.2f); // Give all the same local scale since we want them to blend together a bit
            newCapsule.transform.position = CreationTarget.transform.position; // Set initial position as CreationTarget origin
            newCapsule.transform.position += new Vector3(1f, 2f, 1f); // Offset by the radius we want the circle to start at

            // Get renderer component to change color to "air" color - white
            Renderer rend = newCapsule.GetComponent<Renderer>();
            rend.material.color = new Color(1f, 1f, 1f);
            
            newCapsule.tag = "Air"; // Assign "Air" tag for easy shooting later
            newCapsule.AddComponent<AirCapsule>(); // Add AirCapsule component for rotation definition
            newCapsule.AddComponent<AirCapsuleCircularMotion>(); // Add AirCapsuleCircularMotion component to define the rotation about a defined plane
            // Wait for animation to begin
            yield return new WaitForSeconds(1f / 17f); // Delay to space objects out
        }
        yield return new WaitForSeconds(0.5f); // Wait for animation to settle before moving on
    }

    // Spawns WaterSphere objects that move in a circle about a defined plane for the AvatarState animations
    private IEnumerator SpawnWater()
    {
        // Spawn 20 WaterSphere objects
        for (int i = 0; i < 20; i++)
        {
            GameObject newSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere); // Create primitive shape
            newSphere.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f); // Give all the same local scale since we want them to blend together a bit
            newSphere.transform.position = CreationTarget.transform.position; // Set initial position as CreationTarget origin
            newSphere.transform.position += new Vector3(0f, -1f, -2f); // Offset by the radius we want the circle to start at

            // Get renderer component to change color to "Water" color - blue
            Renderer rend = newSphere.GetComponent<Renderer>();
            rend.material.color = new Color(0f, 0.2f, 1f);

            newSphere.tag = "Water"; // Assign "water" tag for easy shooting later
            // No rotation definition for these, I want them to look like drops of water
            newSphere.AddComponent<WaterSphereCircularMotion>(); // Add WaterSphereCircularMotion to define the rotation about a defined plane
            // Wait for animation to begin
            yield return new WaitForSeconds(1f / 17f); // Delay to space objects out
        }
    }

    // Shoots the AvatarState geometries sequentially towards the camera then deletes them on impact
    private IEnumerator ShootGeometriesSequence()
    {
        // Hold Animation
        yield return new WaitForSeconds(3f);

        // Set target vector past camera position
        Vector3 targetPosition = new Vector3(0f, 8f, -16f);

        // Shoot Earth
        GameObject[] EarthObjs = GameObject.FindGameObjectsWithTag("Earth");
        foreach (GameObject obj in EarthObjs)
        {
            // Disable the previous animation
            MovePentagonally anim = obj.GetComponent<MovePentagonally>();
            if (anim != null)
            {
                anim.enabled = false;
                Destroy(anim);
            }

            yield return ShootObject(obj, targetPosition); // Wait for object to hit the camera
            Destroy(obj); // Delete object
        }

        // Shoot Air
        GameObject[] AirObjs = GameObject.FindGameObjectsWithTag("Air");
        foreach (GameObject obj in AirObjs)
        {
            AirCapsuleCircularMotion anim = obj.GetComponent<AirCapsuleCircularMotion>();
            if (anim != null)
            {
                anim.enabled = false;
            }

            yield return ShootObject(obj, targetPosition);
            obj.tag = "DynamicObject";
            Destroy(obj);
        }

        // Shoot Fire
        GameObject[] FireObjs = GameObject.FindGameObjectsWithTag("Fire");
        foreach (GameObject obj in FireObjs)
        {
            FireCubeCircularMotion anim = obj.GetComponent<FireCubeCircularMotion>();
            if (anim != null)
            {
                anim.enabled = false;
            }

            yield return ShootObject(obj, targetPosition);
            obj.tag = "DynamicObject";
            Destroy(obj);
        }

        // Shoot Water
        GameObject[] WaterObjs = GameObject.FindGameObjectsWithTag("Water");
        foreach (GameObject obj in WaterObjs)
        {
            WaterSphereCircularMotion anim = obj.GetComponent<WaterSphereCircularMotion>();
            if (anim != null)
            {
                anim.enabled = false;
            }

            yield return ShootObject(obj, targetPosition);
            obj.tag = "DynamicObject";
            Destroy(obj);
        }

        DeleteAllObjects(); // Delete any dynamic objects to reset the game state after the animation
        yield return new WaitForSeconds(1.5f); // Wait to ensure Delete has time to work
    }

    // Shoots a gameObject towards a targetPosition
    public IEnumerator ShootObject(GameObject obj, Vector3 targetPosition)
    {
        float speed = 2f;

        while (obj != null && obj.transform.position != targetPosition)
        {
            float step = speed * Time.smoothDeltaTime;
            obj.transform.position = Vector3.MoveTowards(obj.transform.position, targetPosition, step);
            speed++; // Accelerate
            yield return null;
        }
    }
}
