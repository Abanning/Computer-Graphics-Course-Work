//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/createCube.cs - Called by 'Create Cube' toggle event created
//@description: A script that creates a Cube primitive at the CreationTarget position whenever the 'Create Cube' toggle is selected
//              and adds a CustomPrimitiveCube component to this object aligned with the definition in the MP1 - assignment spec

using UnityEngine;

public class createCube : MonoBehaviour
{
    public GameObject CreationTarget;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    // Event listener connected to CubeToggle
    public void OnToggleChange(bool isOn)
    {
        if (isOn && CreationTarget != null)
        {
            GameObject newCube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            newCube.transform.position = CreationTarget.transform.position;
            newCube.transform.position += new Vector3(0f, 0.3f, 0f);
            newCube.AddComponent<CustomPrimitiveCube>();
        }
    }
}
