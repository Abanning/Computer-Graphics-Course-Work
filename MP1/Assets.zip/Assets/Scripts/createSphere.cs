//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/createSphere.cs - Called by 'Create Sphere' toggle event
//@description: A script that creates a Sphere primitive at the CreationTarget position whenever the 'Create Sphere' toggle is selected
//              and adds a CustomPrimitiveSphere component to this object aligned with the definition in the MP1 - assignment spec

using UnityEngine;

public class createSphere : MonoBehaviour
{
    public GameObject CreationTarget;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }

    // Event listener connected to SphereToggle
    public void OnToggleChanged(bool isOn)
    {
        if (isOn && CreationTarget != null)
        {
            GameObject newSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            newSphere.transform.position = CreationTarget.transform.position;
            newSphere.AddComponent<CustomPrimitiveSphere>();
        }
    }
}
