//@author: Alex Banning
//@lastModified: October 3rd, 2025
//@filename/context: AlexBanningMP1/Assets/Scripts/CustomPrimitiveCube.cs - Component added to GameObject called by createCube.cs
//@description: Defines the custom shape and behavior of a primitive cube object as outlined in MP1 - assignment spec

using System;
using UnityEngine;
using UnityEngine.UI;

public class CustomPrimitiveCube : MonoBehaviour
{
    public ToggleGroup ToggleGroup;
    public float speed = 2.0f; // Set movement speed
    public float rotationSpeed = 135f; // Set angular speed
    
    // Define upper and lower bounds
    public float minX = 0.0f;
    public float maxX = 5.0f;

    private Vector3 direction = Vector3.right; // Set direction vector
    private Renderer rend;
    private bool reverseFlag = false; // Needed in case of placing object "out of bounds"
    private readonly String objectTag = "DynamicObject"; // A tag for easy sorting of all dynamic objects created

    // Start is called before the first frame update
    void Start()
    {
        // Define the object tag at creation
        gameObject.tag = objectTag;
        transform.localScale = new Vector3(1f, 1f, 1f); // Set scale

        // If out of bounds, reverse direction
        if (transform.position.x > maxX)
        {
            direction = Vector3.left;
        }

        // Get ToggleGroup
        GameObject groupObj = GameObject.FindGameObjectWithTag("PrimTog");
        if (groupObj != null)
        {
            ToggleGroup = groupObj.GetComponent<ToggleGroup>();
        }

        rend = GetComponent<Renderer>();
        UpdateColor();
    }

    // Update is called once per frame
    void Update()
    {
        // Check for mouse click
        if (Input.GetMouseButtonDown(0))
        {
            DestructionHandler();
        }

        // Update position
        transform.position += speed * Time.smoothDeltaTime * direction;

        // Check for out of bounds
        if (transform.position.x >= maxX)
        {
            direction = Vector3.left;
            UpdateColor();
            reverseFlag = true;
        }
        else if (transform.position.x <= minX && reverseFlag)
        {
            direction = Vector3.right;
            UpdateColor();
        }

        transform.Rotate(Vector3.up, rotationSpeed * Time.smoothDeltaTime); // Update rotation
    }

    // Updates the renderer material color
    void UpdateColor()
    {
        if (rend != null)
        {
            rend.material.color = (direction == Vector3.right) ? new Color(1f, 1f, 1f) : new Color(1f, 1f, 0f);
        }
    }

    // After a mouse click event, Destruction handler checks to see if the mouse click happened on this.gameObject
    // If so, destroy the object
    void DestructionHandler()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider.gameObject == gameObject)
            {
                // Clear toggles on destruction
                ClearToggles();
                Destroy(gameObject);
            }
        }
    }
    
    // Function that clears all toggles in the Function ToggleGroup in the UI
    public void ClearToggles()
    {
        if (ToggleGroup != null)
        {
            ToggleGroup.SetAllTogglesOff();
        }
    }
}